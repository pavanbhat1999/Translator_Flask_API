from translate import Translator
translator= Translator(to_lang="German")
translation = translator.translate("Good Morning!")
print (translation)

